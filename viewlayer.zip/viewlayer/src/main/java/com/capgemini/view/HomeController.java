package com.capgemini.view;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.view.HomeService;
import com.capgemini.view.Contact;
import com.capgemini.view.Feedback;

@RestController
public class HomeController {

	@Autowired
	private HomeService service;
	
	@RequestMapping("/home")
	public ModelAndView home() {
		ModelAndView mav= new ModelAndView("home");
		return mav;
	}
	@RequestMapping("/faq")
	public ModelAndView faq() {
		ModelAndView mav= new ModelAndView("faq");
		return mav;
	}
	@RequestMapping("/category")
	public ModelAndView category() {
		ModelAndView mav= new ModelAndView("category");
		return mav;
	}
	@RequestMapping("/contact")
	public ModelAndView contact() {
		ModelAndView mav= new ModelAndView("contact");
		return mav;
	}
	@RequestMapping("/feedback")
	public ModelAndView feedback() {
		ModelAndView mav= new ModelAndView("feedback");
		return mav;
	}
	@RequestMapping("/privacy")
	public ModelAndView privacy() {
		ModelAndView mav= new ModelAndView("PrivacyPolicy");
		return mav;
	}@RequestMapping("/terms")
	public ModelAndView terms() {
		ModelAndView mav= new ModelAndView("termsOfUse");
		return mav;
	}
	
	@RequestMapping(value="/submitFeedback", method = RequestMethod.POST)
	public ModelAndView Feedback(Model model, @ModelAttribute("feedback") Feedback feedback, @ModelAttribute("firstName")String firstName, @ModelAttribute("lastName")String lastName, @ModelAttribute("email")String email, @ModelAttribute("phone")String phone, @ModelAttribute("message")String message) {
			Feedback feedback1= service.submitFeedback(firstName, lastName, email, phone, message);
			ModelAndView mav = new ModelAndView(); 
			mav.addObject("feedback", feedback1);
			
			mav.setViewName("feedback");
			
			return mav;
	}
	
	@RequestMapping(value="/submitContact", method = RequestMethod.POST)
	public ModelAndView Contact(Model model, @ModelAttribute("contact") Contact contact, @ModelAttribute("name")String name, @ModelAttribute("email")String email, @ModelAttribute("phone")String phone, @ModelAttribute("query")String query) {
			Contact contact1= service.submitContact(name, email, phone, query);
			ModelAndView mav = new ModelAndView(); 
			mav.addObject("contact", contact1);
			
			mav.setViewName("contact");
			return mav;
		
	}
	
	
	
	
	
}
