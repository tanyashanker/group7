package com.capgemini.view;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.bechdalo.group7.UserRepository;
import com.capgemini.view.Contact;
import com.capgemini.view.Feedback;

public class HomeService {

	@Autowired
	private Feedback feedrepo;
	@Autowired
	private Contact contactrepo;
	public Feedback create(String firstName, String lastName, String email, String phone, String message)
	{
		return feedrepo.save(new Feedback(firstName, lastName, email, phone, message));
	}
	
	public Contact submitContact(String name, String email, String phone, String query)
	{
		return contactrepo.save(new Contact(name, email, phone, query));
	}
	
}
